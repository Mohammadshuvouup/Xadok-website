import React, { useState, useEffect } from "react";
import { Col, Image, Modal, Row, Carousel, Card, CardDeck } from "react-bootstrap";
import { useTranslation } from "react-i18next";

const API_PREFIX_URL = `https://deliveryxadok.s3.us-east-2.amazonaws.com/`;
var xadokCartItems = [];

function ProductModal(props) {
  const [num, setNum] = useState(1);
  const plus = () => {
    setNum(num + 1);
  };
  const minus = () => {
    setNum(num - 1);
  };
  const { t, i18n } = useTranslation();

  useEffect(() => {
    let language = localStorage.getItem("language");

    // console.log("LANGUAGE SELECTED", language);

    if (language && language.length !== 0) {
      i18n.changeLanguage(language);
    }
  }, []);

  const [cart_quantity, setCart_quantity] = useState(0);

  const addXadokCart = () => {
    if (xadokCartItems.some((item) => item.pro_id == props.cartData.pro_id)) {
      xadokCartItems.map((value, index) => {
        if (value.pro_id == props.cartData.pro_id) {
          value.pro_qua = value.pro_qua + 1;
          // value.pro_qua=num+1;
          // setNum(value.pro_qua);
        }
      });
    } else {
      xadokCartItems.push({
        pro_id: props.cartData.pro_id,
        pro_name: props.cartData.pro_name_en,
        pro_qua: num,
        pro_model: 0,
        product_price:
          props.cartData.pro_special_price == 0 ||
          props.cartData.pro_special_price == ""
            ? props.cartData.pro_price
            : props.cartData.pro_special_price,
        img: API_PREFIX_URL + props.cartData.pro_img,
        offer_price: props.cartData.pro_special_price,
        offer_percent: 0,
        offer_info: props.cartData.pro_desc_en,
      });
      let qty = cart_quantity + 1;
      setCart_quantity(qty);
      setNum(1);
      // setNum(props.cartData.pro_qua);
    }

    localStorage.setItem("xadokCartItems", JSON.stringify(xadokCartItems));
    localStorage.setItem("cart_quantity", JSON.stringify(cart_quantity));

    localStorage.setItem("modal_cart_quantity", JSON.stringify(num));
  };

  return (
    <Modal show={props.show} onHide={props.onHide} className="modal-box">
      <Modal.Header closeButton>
        <Row>
          <Col md={6}>
            <Image src={`${API_PREFIX_URL}${props.cartData.pro_img}`}></Image>
          </Col>
          <Col md={6}>
            <Modal.Title>{props.cartData.product}</Modal.Title>
            <h6 className="mt-5">
              {t("subCategory.categories")}{" "}
              <span>{props.cartData.category}</span>
            </h6>
            <h6 className="mt-2">
              {t("subCategory.description")}{" "}
              <span>{props.cartData.pro_desc_en}</span>
            </h6>
            <del className="text-muted mt-3">{props.cartData.pro_price}</del>
            <div className="d-flex align-items-center price-box mt-1">
              <span className="current-price mr-1">
                {props.cartData.pro_price}
              </span>
              <span className="currency">BHD</span>
              <div className="discount">25%</div>
            </div>
            <p className="note mt-2">{t("subCategory.add-to-cart_note")}</p>

            <div className="cart-options d-flex align-items-center">
              <div className="input-group plus-minus-input">
                <div className="input-group-button">
                  <button
                    type="button"
                    className="sign-btn minus"
                    data-quantity="minus"
                    data-field="quantity"
                    onClick={minus}
                  >
                    <i className="fa fa-minus" aria-hidden="true"></i>
                  </button>
                </div>
                <input
                  className="input-group-field"
                  type="number"
                  name="quantity"
                  value={num}
                />
                <div className="input-group-button">
                  <button
                    type="button"
                    className="sign-btn hollow plus"
                    data-quantity="plus"
                    data-field="quantity"
                    onClick={plus}
                  >
                    <i className="fa fa-plus" aria-hidden="true"></i>
                  </button>
                </div>
              </div>

              <button className="modal_addcart_btn" onClick={addXadokCart}>
                <i className="fas fa-shopping-cart mr-2"></i>{" "}
                {t("explore.add-to-cart")}{" "}
              </button>
              <i class="fas fa-heart favourite-icon"></i>
            </div>
          </Col>
        </Row>
      </Modal.Header>
      <Modal.Body>
        {/* =============== Alternnative Products ========== */}
        <h2>{t("subCategory.Alternative-Products")}</h2>
        <Row className="modal-carousel-row">
          <Carousel classname="alternative-items-carousel">
            {!props.slide_product
              ? null
              : props.alternative_Product.map((product, index) => (
                  <Carousel.Item>
                    <CardDeck>
                      {product.map((val, index) =>
                        !val ? null : (
                          <Card className="alternative-item">
                            <Card.Img src={`${API_PREFIX_URL}${val.pro_img}`} />
                            <Card.Body>
                              <Card.Text>
                                <p className="pl-2 old_price">
                                  <del>{val.pro_price}</del>
                                </p>
                                <div className="priceBox">
                                  <h4 className="pl-2 item_price">
                                    {val.pro_special_price}
                                    <span className="currency-symbol">BDH</span>
                                  </h4>
                                  <div className="discount">
                                    <p className="pt-1 pl-3 ptag">25%</p>
                                  </div>
                                </div>
                                <p className="item_description">
                                  {val.pro_name}
                                </p>
                              </Card.Text>
                              <button className="addcartBtn">
                                <i className="fas fa-shopping-cart mr-2"></i>{" "}
                                {t("explore.add-to-cart")}{" "}
                              </button>
                            </Card.Body>
                          </Card>
                        )
                      )}
                    </CardDeck>
                  </Carousel.Item>
                ))}
          </Carousel>
        </Row>

        {/* =============== Similar Products ========== */}
        <h2 className="mt-3">{t("explore.similar-products")}</h2>
        <Row className="modal-carousel-row">
          <Carousel classname="alternative-items-carousel">
            {props.cartSimilar_Product &&
              props.cartSimilar_Product.length > 0 &&
              props.cartSimilar_Product.map((value, index) => {
                return (
                  <Carousel.Item key={index}>
                    <CardDeck>
                      {value.map((val, index) =>
                        !val ? null : (
                          <Card className="alternative-item">
                            <Card.Img src={`${API_PREFIX_URL}${val.pro_img}`} />
                            <Card.Body>
                              <Card.Text>
                                <p className="pl-2 old_price">
                                  <del>{val.pro_price}</del>
                                </p>
                                <div className="priceBox">
                                  <h4 className="pl-2 item_price">
                                    {val.pro_special_price}
                                    <span className="currency-symbol">BDH</span>
                                  </h4>
                                  <div className="discount">
                                    <p className="pt-1 pl-3 ptag">25%</p>
                                  </div>
                                </div>
                                <p className="item_description">
                                  {val.pro_name}
                                </p>
                              </Card.Text>
                              <button className="addcartBtn">
                                <i className="fas fa-shopping-cart mr-2"></i>{" "}
                                {t("explore.add-to-cart")}{" "}
                              </button>
                            </Card.Body>
                          </Card>
                        )
                      )}
                    </CardDeck>
                  </Carousel.Item>
                );
              })}
          </Carousel>
        </Row>
      </Modal.Body>
    </Modal>
  );
}

export default ProductModal