import React from 'react'

const NoProduct=()=>{
    return(
        <div>
            no products
        </div>
    );
}

export default NoProduct;